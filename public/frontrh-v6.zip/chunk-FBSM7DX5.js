import{a as A}from"./chunk-FGONHSP3.js";import{a as O}from"./chunk-X4X54WXF.js";import{a as Q}from"./chunk-MKAHHN3L.js";import{g as B,l as j}from"./chunk-CULIKSWT.js";import{Ab as T,Bb as _,Ca as r,Eb as a,Fb as u,Gb as x,Hb as S,M as F,Ob as C,Qa as R,Rb as w,Sb as k,T as f,U as b,Wa as y,Yb as N,ba as E,fb as m,gb as t,hb as n,ib as g,oc as P,pc as z,rb as v,sb as h,wc as H}from"./chunk-XABULFCZ.js";import"./chunk-C6Q5SG76.js";var M=d=>[d];function U(d,i){if(d&1&&(t(0,"option",40),a(1),n()),d&2){let e=i.$implicit;m("value",e),r(),u(e)}}function W(d,i){if(d&1&&(t(0,"div",65),a(1),n()),d&2){let e=h().$implicit;r(),x(" ",e.activeContract==null?null:e.activeContract.modality," ")}}function J(d,i){if(d&1&&(t(0,"div",66),a(1),n()),d&2){let e=h().$implicit,o=h(2);r(),x(" en ",o.getDaysRemaining(e.activeContract==null?null:e.activeContract.endDate)," d\xEDas ")}}function K(d,i){if(d&1&&(t(0,"tr",48)(1,"td",33),v("click",function(o){return o.stopPropagation()}),g(2,"input",44),n(),t(3,"td")(4,"div",49)(5,"span",50),a(6),n(),t(7,"div")(8,"div",51),a(9),n(),t(10,"div",52),a(11),n()()()(),t(12,"td"),a(13),n(),t(14,"td")(15,"span",53),a(16),n()(),t(17,"td")(18,"div",54),a(19),n(),y(20,W,2,1,"div",55),n(),t(21,"td")(22,"span",56),a(23),n()(),t(24,"td",45),a(25),w(26,"hrCurrency"),n(),t(27,"td",57),a(28),w(29,"peDate"),y(30,J,2,1,"div",58),n(),t(31,"td",59),v("click",function(o){return o.stopPropagation()}),t(32,"button",60),f(),t(33,"svg",61),g(34,"circle",62)(35,"circle",63)(36,"circle",64),n()()()()),d&2){let e=i.$implicit,o=h(2);m("routerLink",C(26,M,e.id)),r(5),T("background",o.getAvatarColor(e.fullName)),r(),x(" ",o.getInitials(e.fullName)," "),r(3),u(e.fullName),r(2),S("DNI ",e.dni," \xB7 ",e.email),r(2),u(e.position),r(3),u(e.department),r(3),u((e.activeContract==null?null:e.activeContract.nature)??"Indeterminado"),r(),m("ngIf",e.activeContract==null?null:e.activeContract.modality),r(2),_("success",o.getComputedStatus(e)==="Vigente")("warning",o.getComputedStatus(e)==="Por vencer")("danger",o.getComputedStatus(e)==="Vencido"),r(),x(" ",o.getComputedStatus(e)," "),r(2),u(k(26,22,e.basicSalary)),r(3),x(" ",e.activeContract!=null&&e.activeContract.endDate?k(29,24,e.activeContract==null?null:e.activeContract.endDate):"\u2014"," "),r(2),m("ngIf",o.getDaysRemaining(e.activeContract==null?null:e.activeContract.endDate)!==null&&o.getDaysRemaining(e.activeContract==null?null:e.activeContract.endDate)<=30&&o.getDaysRemaining(e.activeContract==null?null:e.activeContract.endDate)>=0),r(2),m("routerLink",C(28,M,e.id))}}function X(d,i){d&1&&(t(0,"tr")(1,"td",67),a(2," No se encontraron colaboradores con los filtros activos. "),n()())}function Y(d,i){if(d&1&&(t(0,"div",41)(1,"table",42)(2,"thead")(3,"tr")(4,"th",43),g(5,"input",44),n(),t(6,"th"),a(7,"Colaborador"),n(),t(8,"th"),a(9,"Cargo"),n(),t(10,"th"),a(11,"\xC1rea"),n(),t(12,"th"),a(13,"Modalidad"),n(),t(14,"th"),a(15,"Estado"),n(),t(16,"th",45),a(17,"Remuneraci\xF3n"),n(),t(18,"th"),a(19,"Vence"),n(),g(20,"th"),n()(),t(21,"tbody"),y(22,K,37,30,"tr",46)(23,X,3,0,"tr",47),n()()()),d&2){let e=h();r(22),m("ngForOf",e.filteredEmployees()),r(),m("ngIf",e.filteredEmployees().length===0)}}function Z(d,i){if(d&1&&(t(0,"div",70)(1,"div",71)(2,"div",72)(3,"span",73),a(4),n(),t(5,"div",74)(6,"div",75),a(7),n(),t(8,"div",76),a(9),n()()(),t(10,"div",77)(11,"span",78),a(12,"DNI"),n(),t(13,"span",39),a(14),n()(),t(15,"div",79)(16,"span",78),a(17,"\xC1rea"),n(),t(18,"span"),a(19),n()(),t(20,"div",79)(21,"span",78),a(22,"Remun."),n(),t(23,"span",39),a(24),w(25,"hrCurrency"),n()(),t(26,"div",80)(27,"span",56),a(28),n()()()()),d&2){let e=i.$implicit,o=h(2);m("routerLink",C(18,M,e.id)),r(3),T("background",o.getAvatarColor(e.fullName)),r(),x(" ",o.getInitials(e.fullName)," "),r(3),u(e.fullName),r(2),u(e.position),r(5),u(e.dni),r(5),u(e.department),r(5),u(k(25,16,e.basicSalary)),r(3),_("success",o.getComputedStatus(e)==="Vigente")("warning",o.getComputedStatus(e)==="Por vencer")("danger",o.getComputedStatus(e)==="Vencido"),r(),x(" ",o.getComputedStatus(e)," ")}}function ee(d,i){if(d&1&&(t(0,"div",68),y(1,Z,29,20,"div",69),n()),d&2){let e=h();r(),m("ngForOf",e.filteredEmployees())}}var q=class d{employeeService=F(Q);employees=E([]);viewMode=E("table");searchQuery=E("");selectedDept=E("Todos");selectedStatus=E("Todos");departments=N(()=>{let i=this.employees();return Array.from(new Set(i.map(e=>e.department).filter(Boolean)))});filteredEmployees=N(()=>{let i=this.employees(),e=this.searchQuery().toLowerCase(),o=this.selectedDept(),s=this.selectedStatus();return e&&(i=i.filter(l=>l.fullName.toLowerCase().includes(e)||l.dni.includes(e)||l.position.toLowerCase().includes(e))),o!=="Todos"&&(i=i.filter(l=>l.department===o)),s!=="Todos"&&(i=i.filter(l=>this.getComputedStatus(l)===s)),i});ngOnInit(){this.loadEmployees()}async loadEmployees(){try{let i=await this.employeeService.getEmployees(void 0,void 0,1,100);this.employees.set(i.data)}catch(i){console.error("Error al cargar colaboradores",i)}}setViewMode(i){this.viewMode.set(i)}onSearch(i){let e=i.target.value;this.searchQuery.set(e.trim())}onDeptFilter(i){let e=i.target.value;this.selectedDept.set(e)}onStatusFilter(i){let e=i.target.value;this.selectedStatus.set(e)}getInitials(i){return i?i.split(" ").filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase():"HR"}getAvatarColor(i){if(!i)return"oklch(0.65 0.12 250)";let e=[...i].reduce((s,l)=>s+l.charCodeAt(0),0),o=[30,60,145,200,240,280,320,10];return`oklch(0.65 0.12 ${o[e%o.length]})`}getDaysRemaining(i){if(!i)return null;let e=new Date(i+"T00:00:00"),o=new Date;o.setHours(0,0,0,0);let s=e.getTime()-o.getTime();return Math.ceil(s/(1e3*60*60*24))}getComputedStatus(i){if(!i.activeContract)return"Vigente";if(i.activeContract.status==="expired"||i.activeContract.status==="terminated")return"Vencido";let e=this.getDaysRemaining(i.activeContract.endDate);return e!==null&&e<=30&&e>=0?"Por vencer":e!==null&&e<0?"Vencido":"Vigente"}importData(){let i=document.createElement("input");i.type="file",i.accept=".csv",i.onchange=async e=>{let o=e.target.files[0];if(!o)return;let s=new FileReader;s.onload=async l=>{let $=l.target.result.split(`
`),I=0;for(let L=1;L<$.length;L++){let V=$[L].trim();if(!V)continue;let p=V.split(",").map(D=>D.replace(/^"|"$/g,"").trim());if(p.length<6)continue;let G={dni:p[0],firstName:p[1],lastName:p[2],position:p[3],phone:p[4]||null,email:p[5],address:p[6]||null,district:p[7]||null,province:p[8]||null,department:p[9]||null,ubigeoCode:p[10]||null,basicSalary:p[11]?parseFloat(p[11]):0};try{await this.employeeService.createEmployee(G),I++}catch(D){console.error("Error importing row",D)}}I>0?(alert(`Importaci\xF3n masiva completada con \xE9xito. Se registraron ${I} colaboradores.`),await this.loadEmployees()):alert("No se pudieron importar registros. Verifique el formato del archivo CSV.")},s.readAsText(o)},i.click()}exportData(){let i=this.employees();if(i.length===0){alert("No hay colaboradores registrados para exportar.");return}let e="\uFEFF";e+=`DNI,Nombres,Apellidos,Puesto,Celular,Correo,Direcci\xF3n,Distrito,Provincia,Departamento,Ubigeo,Sueldo
`,i.forEach(c=>{e+=`"${c.dni}","${c.firstName}","${c.lastName}","${c.position}","${c.phone||""}","${c.email}","${c.address||""}","${c.district||""}","${c.province||""}","${c.department||""}","${c.ubigeoCode||""}",${c.basicSalary||0}
`});let o=new Blob([e],{type:"text/csv;charset=utf-8;"}),s=window.URL.createObjectURL(o),l=document.createElement("a");l.href=s,l.download="listado_colaboradores.csv",document.body.appendChild(l),l.click(),document.body.removeChild(l),window.URL.revokeObjectURL(s)}printBatchQrs(){let i=this.filteredEmployees().filter(l=>l.qrCodeToken);if(i.length===0){alert("No hay colaboradores con c\xF3digos QR para exportar en este lote.");return}let e=window.open("","_blank");if(!e){alert("Por favor habilita las ventanas emergentes (popups) para exportar el lote.");return}let o="Constructora Norte S.A.C.",s=i.map(l=>`
            <div class="badge-card">
                <div class="badge-header">
                    <div class="badge-logo">RH</div>
                    <div class="badge-brand">
                        <span class="company-name">${o}</span>
                        <span class="badge-tag">CREDENCIAL ASISTENCIA</span>
                    </div>
                </div>
                <div class="badge-body">
                    <img class="qr-img" src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${l.qrCodeToken}" alt="QR" />
                    <div class="emp-name">${l.firstName} ${l.lastName}</div>
                    <div class="emp-pos">${l.position}</div>
                </div>
                <div class="badge-footer">
                    Token: ${l.qrCodeToken}
                </div>
            </div>
        `).join("");e.document.write(`
            <html>
                <head>
                    <title>Credenciales QR - Lote</title>
                    <style>
                        body {
                            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                            background: #f8fafc;
                            margin: 0;
                            padding: 20px;
                            color: #1e293b;
                        }
                        .print-header {
                            margin-bottom: 24px;
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            border-bottom: 2px solid #e2e8f0;
                            padding-bottom: 12px;
                        }
                        .print-header h1 {
                            font-size: 20px;
                            margin: 0;
                        }
                        .print-btn {
                            background: #06b6d4;
                            color: white;
                            border: none;
                            padding: 8px 16px;
                            border-radius: 6px;
                            font-weight: 600;
                            cursor: pointer;
                        }
                        .badges-grid {
                            display: grid;
                            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                            gap: 20px;
                        }
                        .badge-card {
                            background: white;
                            border: 1px solid #cbd5e1;
                            border-radius: 12px;
                            padding: 16px;
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            text-align: center;
                            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
                            position: relative;
                            page-break-inside: avoid;
                        }
                        .badge-header {
                            display: flex;
                            align-items: center;
                            gap: 10px;
                            width: 100%;
                            border-bottom: 1px solid #e2e8f0;
                            padding-bottom: 8px;
                            margin-bottom: 12px;
                            text-align: left;
                        }
                        .badge-logo {
                            width: 32px;
                            height: 32px;
                            background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
                            color: white;
                            font-weight: 800;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border-radius: 6px;
                            font-size: 14px;
                        }
                        .badge-brand {
                            display: flex;
                            flex-direction: column;
                        }
                        .company-name {
                            font-size: 11px;
                            font-weight: 700;
                            color: #475569;
                            text-transform: uppercase;
                        }
                        .badge-tag {
                            font-size: 8px;
                            font-weight: 700;
                            letter-spacing: 0.5px;
                            color: #94a3b8;
                        }
                        .qr-img {
                            width: 150px;
                            height: 150px;
                            margin-bottom: 12px;
                            display: block;
                            border: 1px solid #e2e8f0;
                            padding: 4px;
                            border-radius: 8px;
                        }
                        .emp-name {
                            font-size: 15px;
                            font-weight: 700;
                            color: #0f172a;
                            margin-bottom: 2px;
                        }
                        .emp-pos {
                            font-size: 12px;
                            color: #64748b;
                        }
                        .badge-footer {
                            margin-top: 12px;
                            font-size: 9px;
                            font-family: monospace;
                            color: #94a3b8;
                            border-top: 1px dashed #e2e8f0;
                            width: 100%;
                            padding-top: 6px;
                        }
                        @media print {
                            .print-header {
                                display: none;
                            }
                            body {
                                background: white;
                                padding: 0;
                            }
                            .badge-card {
                                box-shadow: none;
                                border-color: #94a3b8;
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class="print-header">
                        <h1>Imprimir Lote de Credenciales QR (${i.length})</h1>
                        <button class="print-btn" onclick="window.print()">Imprimir / Guardar PDF</button>
                    </div>
                    <div class="badges-grid">
                        ${s}
                    </div>
                    <script>
                        window.onload = function() {
                            setTimeout(function() { window.print(); }, 500);
                        };
                    <\/script>
                </body>
            </html>
        `),e.document.close()}static \u0275fac=function(e){return new(e||d)};static \u0275cmp=R({type:d,selectors:[["app-employee-list"]],decls:71,vars:11,consts:[[1,"hr-page-header"],[1,"hr-page-title"],[1,"hr-page-sub"],[1,"hr-page-actions"],[1,"hr-btn",3,"click"],["width","16","height","16","viewBox","0 0 24 24","fill","none","stroke","currentColor","stroke-width","1.75","stroke-linecap","round","stroke-linejoin","round"],["d","M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"],["points","17 8 12 3 7 8"],["x1","12","y1","3","x2","12","y2","15"],["points","7 10 12 15 17 10"],["x1","12","y1","15","x2","12","y2","3"],["width","10","height","10","x","3","y","3","rx","2"],["width","6","height","6","x","5","y","5","rx","1"],["width","10","height","10","x","11","y","11","rx","2"],["width","6","height","6","x","13","y","13","rx","1"],["width","6","height","6","x","15","y","3","rx","1"],["width","6","height","6","x","3","y","15","rx","1"],["routerLink","/contratos/nuevo",1,"hr-btn","hr-btn-primary"],["x1","12","y1","5","x2","12","y2","19"],["x1","5","y1","12","x2","19","y2","12"],[1,"hr-filters"],[1,"hr-search-input"],["cx","11","cy","11","r","7"],["d","m20 20-3.5-3.5"],["placeholder","Buscar por nombre, DNI o cargo...",3,"input"],[1,"hr-chip",3,"change"],["value","Todos"],[3,"value",4,"ngFor","ngForOf"],["value","Vigente"],["value","Por vencer"],["value","Vencido"],[1,"hr-spacer"],[1,"hr-seg"],[3,"click"],["class","hr-card hr-card-flush",4,"ngIf"],["style","display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px;",4,"ngIf"],[1,"hr-hstack",2,"margin-top","16px","justify-content","space-between","font-size","13px","color","var(--text-soft)"],[1,"hr-hstack"],["disabled","",1,"hr-btn","hr-btn-sm"],[1,"hr-mono"],[3,"value"],[1,"hr-card","hr-card-flush"],[1,"hr-tbl"],[2,"width","30px"],["type","checkbox"],[1,"num"],["style","cursor: pointer;",3,"routerLink",4,"ngFor","ngForOf"],[4,"ngIf"],[2,"cursor","pointer",3,"routerLink"],[1,"hr-row-emp"],[1,"hr-emp-avatar"],[1,"hr-emp-name"],[1,"hr-emp-id"],[1,"hr-badge","no-dot","neutral"],[2,"font-size","13px"],["style","font-size: 11px; color: var(--text-mute);",4,"ngIf"],[1,"hr-badge"],[1,"hr-mono",2,"font-size","12.5px"],["style","font-size: 10.5px; color: var(--warning); font-weight: 500;",4,"ngIf"],[1,"action-cell",3,"click"],[1,"hr-btn","hr-btn-ghost","hr-btn-icon",3,"routerLink"],["width","18","height","18","viewBox","0 0 24 24","fill","none","stroke","currentColor","stroke-width","1.75","stroke-linecap","round","stroke-linejoin","round"],["cx","12","cy","12","r","1"],["cx","12","cy","5","r","1"],["cx","12","cy","19","r","1"],[2,"font-size","11px","color","var(--text-mute)"],[2,"font-size","10.5px","color","var(--warning)","font-weight","500"],["colspan","9",1,"hr-soft",2,"text-align","center","height","120px"],[2,"display","grid","grid-template-columns","repeat(auto-fill, minmax(280px, 1fr))","gap","12px"],["class","hr-card","style","cursor: pointer;",3,"routerLink",4,"ngFor","ngForOf"],[1,"hr-card",2,"cursor","pointer",3,"routerLink"],[1,"hr-card-body"],[1,"hr-hstack",2,"margin-bottom","12px"],[1,"hr-emp-avatar",2,"width","44px","height","44px","font-size","14px"],[2,"flex","1","min-width","0"],[2,"font-weight","600","font-size","14px","white-space","nowrap","overflow","hidden","text-overflow","ellipsis"],[2,"font-size","12px","color","var(--text-soft)","white-space","nowrap","overflow","hidden","text-overflow","ellipsis"],[1,"hr-hstack",2,"justify-content","space-between","font-size","12px"],[1,"hr-muted"],[1,"hr-hstack",2,"justify-content","space-between","font-size","12px","margin-top","6px"],[2,"margin-top","12px"]],template:function(e,o){e&1&&(t(0,"div",0)(1,"div")(2,"h1",1),a(3,"Colaboradores"),n(),t(4,"p",2),a(5),n()(),t(6,"div",3)(7,"button",4),v("click",function(){return o.importData()}),f(),t(8,"svg",5),g(9,"path",6)(10,"polyline",7)(11,"line",8),n(),a(12," Importar "),n(),b(),t(13,"button",4),v("click",function(){return o.exportData()}),f(),t(14,"svg",5),g(15,"path",6)(16,"polyline",9)(17,"line",10),n(),a(18," Exportar "),n(),b(),t(19,"button",4),v("click",function(){return o.printBatchQrs()}),f(),t(20,"svg",5),g(21,"rect",11)(22,"rect",12)(23,"rect",13)(24,"rect",14)(25,"rect",15)(26,"rect",16),n(),a(27," Descargar QRs (Lote) "),n(),b(),t(28,"a",17),f(),t(29,"svg",5),g(30,"line",18)(31,"line",19),n(),a(32," Nuevo colaborador "),n()()(),b(),t(33,"div",20)(34,"div",21)(35,"span"),f(),t(36,"svg",5),g(37,"circle",22)(38,"path",23),n()(),b(),t(39,"input",24),v("input",function(l){return o.onSearch(l)}),n()(),t(40,"select",25),v("change",function(l){return o.onDeptFilter(l)}),t(41,"option",26),a(42,"Todos los departamentos"),n(),y(43,U,2,2,"option",27),n(),t(44,"select",25),v("change",function(l){return o.onStatusFilter(l)}),t(45,"option",26),a(46,"Todos los estados"),n(),t(47,"option",28),a(48,"Vigente"),n(),t(49,"option",29),a(50,"Por vencer"),n(),t(51,"option",30),a(52,"Vencido"),n()(),g(53,"div",31),t(54,"div",32)(55,"button",33),v("click",function(){return o.setViewMode("table")}),a(56,"Tabla"),n(),t(57,"button",33),v("click",function(){return o.setViewMode("cards")}),a(58,"Tarjetas"),n()()(),y(59,Y,24,2,"div",34)(60,ee,2,1,"div",35),t(61,"div",36)(62,"div"),a(63),n(),t(64,"div",37)(65,"button",38),a(66,"Anterior"),n(),t(67,"span",39),a(68,"1 / 1"),n(),t(69,"button",38),a(70,"Siguiente"),n()()()),e&2&&(r(5),S("",o.filteredEmployees().length," de ",o.employees().length," \xB7 Ficha de Colaboradores"),r(38),m("ngForOf",o.departments()),r(12),_("active",o.viewMode()==="table"),r(2),_("active",o.viewMode()==="cards"),r(2),m("ngIf",o.viewMode()==="table"),r(),m("ngIf",o.viewMode()==="cards"),r(3),S("Mostrando 1\u2013",o.filteredEmployees().length," de ",o.filteredEmployees().length))},dependencies:[H,P,z,j,B,A,O],encapsulation:2})};export{q as EmployeeListComponent};
