import{a as R}from"./chunk-XHOAU7QA.js";import"./chunk-45SOK6LB.js";import{a as H}from"./chunk-FGONHSP3.js";import{a as A}from"./chunk-X4X54WXF.js";import{g as M,l as $}from"./chunk-CULIKSWT.js";import{Ab as P,Bb as u,Ca as l,Eb as a,Fb as s,Gb as y,Hb as N,M as E,Nb as T,Qa as I,R as w,Rb as C,S as k,Sb as S,T as h,U as g,Wa as _,Yb as b,ba as v,fb as f,gb as i,hb as r,ib as p,oc as V,pb as D,pc as L,rb as d,sb as x,wc as F}from"./chunk-XABULFCZ.js";import"./chunk-C6Q5SG76.js";var j=()=>["/colaboradores"];function Q(c,e){if(c&1&&(i(0,"div",38),a(1),r()),c&2){let t=x().$implicit;l(),s(t.modality)}}function Y(c,e){if(c&1){let t=D();i(0,"tr",25)(1,"td",26),a(2),r(),i(3,"td")(4,"div",27)(5,"span",28),a(6),r(),i(7,"div")(8,"div",29),a(9),r(),i(10,"div",30),a(11),r()()()(),i(12,"td")(13,"div",31),a(14),r(),_(15,Q,2,1,"div",32),r(),i(16,"td",26),a(17),C(18,"peDate"),r(),i(19,"td",26),a(20),C(21,"peDate"),r(),i(22,"td",33),a(23),r(),i(24,"td")(25,"span",34),a(26),r()(),i(27,"td",22),a(28),C(29,"hrCurrency"),r(),i(30,"td",35),d("click",function(n){return n.stopPropagation()}),i(31,"button",36),d("click",function(){let n=w(t).$implicit,m=x();return k(m.downloadPdf(n.id))}),h(),i(32,"svg",37),p(33,"path",6)(34,"polyline",7)(35,"line",8),r()()()()}if(c&2){let t=e.$implicit,o=e.index,n=x();f("routerLink",T(27,j)),l(2),N("CTR-",n.getYear(t.startDate),"-",n.formatCode(o+1)),l(3),P("background",n.getAvatarColor(t.employee==null?null:t.employee.fullName)),l(),y(" ",n.getInitials(t.employee==null?null:t.employee.fullName)," "),l(3),s(t.employee==null?null:t.employee.fullName),l(2),s(t.employee==null?null:t.employee.position),l(3),s(t.nature),l(),f("ngIf",t.modality),l(2),s(S(18,21,t.startDate)),l(3),s(t.endDate?S(21,23,t.endDate):"\u2014"),l(3),s(n.getDuration(t.startDate,t.endDate)),l(2),u("success",n.getComputedStatus(t)==="Vigente")("warning",n.getComputedStatus(t)==="Por vencer")("danger",n.getComputedStatus(t)==="Vencido"),l(),y(" ",n.getComputedStatus(t)," "),l(2),s(S(29,25,t.salary))}}function U(c,e){c&1&&(i(0,"tr")(1,"td",39),a(2," No se encontraron contratos con los filtros aplicados. "),r()())}var z=class c{contractService=E(R);contracts=v([]);filter=v("Todos");searchQuery=v("");counts=b(()=>{let e=this.contracts();return{all:e.length,active:e.filter(t=>this.getComputedStatus(t)==="Vigente").length,warning:e.filter(t=>this.getComputedStatus(t)==="Por vencer").length,expired:e.filter(t=>this.getComputedStatus(t)==="Vencido").length}});filteredContracts=b(()=>{let e=this.contracts(),t=this.filter(),o=this.searchQuery().toLowerCase();return t==="Vigentes"?e=e.filter(n=>this.getComputedStatus(n)==="Vigente"):t==="Por vencer"?e=e.filter(n=>this.getComputedStatus(n)==="Por vencer"):t==="Vencidos"&&(e=e.filter(n=>this.getComputedStatus(n)==="Vencido")),o&&(e=e.filter(n=>n.employee?.fullName.toLowerCase().includes(o)||n.employee?.dni.includes(o))),e});ngOnInit(){this.loadContracts()}async loadContracts(){try{let e=await this.contractService.getContracts(void 0,void 0,void 0,1,100);this.contracts.set(e.data)}catch(e){console.error("Error al cargar contratos",e)}}setFilter(e){this.filter.set(e)}onSearch(e){let t=e.target.value;this.searchQuery.set(t.trim())}getYear(e){return e?e.split("-")[0]:"2026"}formatCode(e){return e.toString().padStart(4,"0")}getInitials(e){return e?e.split(" ").filter(Boolean).slice(0,2).map(t=>t[0]).join("").toUpperCase():"HR"}getAvatarColor(e){if(!e)return"oklch(0.65 0.12 250)";let t=[...e].reduce((n,m)=>n+m.charCodeAt(0),0),o=[30,60,145,200,240,280,320,10];return`oklch(0.65 0.12 ${o[t%o.length]})`}getDaysRemaining(e){if(!e)return null;let t=new Date(e+"T00:00:00"),o=new Date;o.setHours(0,0,0,0);let n=t.getTime()-o.getTime();return Math.ceil(n/(1e3*60*60*24))}getDuration(e,t){if(!t)return"Indef.";let o=new Date(e+"T00:00:00"),n=new Date(t+"T00:00:00");return`${(n.getFullYear()-o.getFullYear())*12+(n.getMonth()-o.getMonth())} meses`}getComputedStatus(e){if(e.status==="expired"||e.status==="terminated")return"Vencido";let t=this.getDaysRemaining(e.endDate);return t!==null&&t<=30&&t>=0?"Por vencer":t!==null&&t<0?"Vencido":"Vigente"}downloadPdf(e){this.contractService.downloadContractPdf(e)}exportPdf(){let e=this.contracts();if(e.length===0){alert("No hay contratos registrados para exportar.");return}let t=window.open("","_blank");if(!t){alert("Por favor habilita las ventanas emergentes (popups) para exportar el reporte.");return}let o="";e.forEach(n=>{let m=n.employee?`${n.employee.firstName} ${n.employee.lastName}`:"N/A",B=n.employee?n.employee.dni:"N/A",O=n.employee?n.employee.position:"N/A",G=new Intl.NumberFormat("es-PE",{style:"currency",currency:"PEN"}).format(n.salary);o+=`
                <tr>
                    <td>${m}</td>
                    <td>${B}</td>
                    <td>${O}</td>
                    <td>${n.nature}</td>
                    <td>${G}</td>
                    <td>${n.startDate}</td>
                    <td>${n.endDate||"Indefinido"}</td>
                    <td>${n.status==="active"?"Vigente":"Inactivo"}</td>
                </tr>
            `}),t.document.write(`
            <html>
            <head>
                <title>Reporte de Contratos - NOVARIX S.A.C.</title>
                <style>
                    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 20px; color: #333; }
                    h1 { font-size: 20px; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 0.5px; }
                    p { font-size: 12px; margin-bottom: 20px; color: #666; }
                    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                    th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; font-size: 11px; }
                    th { background-color: #f5f5f5; font-weight: bold; text-transform: uppercase; font-size: 10px; }
                    tr:nth-child(even) { background-color: #fafafa; }
                </style>
            </head>
            <body>
                <h1>Reporte de Contratos</h1>
                <p>NOVARIX S.A.C. &middot; Generado el: ${new Date().toLocaleDateString("es-PE")} &middot; Total contratos: ${e.length}</p>
                <table>
                    <thead>
                        <tr>
                            <th>Colaborador</th>
                            <th>DNI</th>
                            <th>Puesto</th>
                            <th>Naturaleza</th>
                            <th>Sueldo</th>
                            <th>Fecha Inicio</th>
                            <th>Fecha Fin</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        \${rowsHtml}
                    </tbody>
                </table>
                <script>
                    window.onload = function() {
                        window.print();
                        window.close();
                    };
                <\/script>
            </body>
            </html>
        `),t.document.close()}static \u0275fac=function(t){return new(t||c)};static \u0275cmp=I({type:c,selectors:[["app-contract-list"]],decls:66,vars:15,consts:[[1,"hr-page-header"],[1,"hr-page-title"],[1,"hr-page-sub"],[1,"hr-page-actions"],[1,"hr-btn",3,"click"],["width","16","height","16","viewBox","0 0 24 24","fill","none","stroke","currentColor","stroke-width","1.75","stroke-linecap","round","stroke-linejoin","round"],["d","M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"],["points","7 10 12 15 17 10"],["x1","12","y1","15","x2","12","y2","3"],["routerLink","nuevo",1,"hr-btn","hr-btn-primary"],["x1","12","y1","5","x2","12","y2","19"],["x1","5","y1","12","x2","19","y2","12"],[1,"hr-filters"],[1,"hr-chip",3,"click"],[2,"opacity","0.6","margin-left","4px"],[1,"hr-spacer"],[1,"hr-search-input"],["cx","11","cy","11","r","7"],["d","m20 20-3.5-3.5"],["placeholder","Buscar contrato...",3,"input"],[1,"hr-card","hr-card-flush"],[1,"hr-tbl"],[1,"num"],["style","cursor: pointer;",3,"routerLink",4,"ngFor","ngForOf"],[4,"ngIf"],[2,"cursor","pointer",3,"routerLink"],[1,"hr-mono",2,"font-size","12.5px"],[1,"hr-row-emp"],[1,"hr-emp-avatar"],[1,"hr-emp-name"],[1,"hr-emp-id"],[2,"font-size","13px"],["style","font-size: 11px; color: var(--text-mute);",4,"ngIf"],[1,"hr-soft",2,"font-size","13px"],[1,"hr-badge"],[1,"action-cell",3,"click"],[1,"hr-btn","hr-btn-ghost","hr-btn-icon",3,"click"],["width","18","height","18","viewBox","0 0 24 24","fill","none","stroke","currentColor","stroke-width","1.75","stroke-linecap","round","stroke-linejoin","round"],[2,"font-size","11px","color","var(--text-mute)"],["colspan","9",1,"hr-soft",2,"text-align","center","height","120px"]],template:function(t,o){t&1&&(i(0,"div",0)(1,"div")(2,"h1",1),a(3,"Contratos"),r(),i(4,"p",2),a(5),r()(),i(6,"div",3)(7,"button",4),d("click",function(){return o.exportPdf()}),h(),i(8,"svg",5),p(9,"path",6)(10,"polyline",7)(11,"line",8),r(),a(12," Exportar PDF "),r(),g(),i(13,"a",9),h(),i(14,"svg",5),p(15,"line",10)(16,"line",11),r(),a(17," Nuevo contrato "),r()()(),g(),i(18,"div",12)(19,"button",13),d("click",function(){return o.setFilter("Todos")}),a(20," Todos "),i(21,"span",14),a(22),r()(),i(23,"button",13),d("click",function(){return o.setFilter("Vigentes")}),a(24," Vigentes "),i(25,"span",14),a(26),r()(),i(27,"button",13),d("click",function(){return o.setFilter("Por vencer")}),a(28," Por vencer "),i(29,"span",14),a(30),r()(),i(31,"button",13),d("click",function(){return o.setFilter("Vencidos")}),a(32," Vencidos "),i(33,"span",14),a(34),r()(),p(35,"div",15),i(36,"div",16)(37,"span"),h(),i(38,"svg",5),p(39,"circle",17)(40,"path",18),r()(),g(),i(41,"input",19),d("input",function(m){return o.onSearch(m)}),r()()(),i(42,"div",20)(43,"table",21)(44,"thead")(45,"tr")(46,"th"),a(47,"C\xF3digo"),r(),i(48,"th"),a(49,"Colaborador"),r(),i(50,"th"),a(51,"Modalidad"),r(),i(52,"th"),a(53,"Inicio"),r(),i(54,"th"),a(55,"T\xE9rmino"),r(),i(56,"th"),a(57,"Duraci\xF3n"),r(),i(58,"th"),a(59,"Estado"),r(),i(60,"th",22),a(61,"Remun."),r(),p(62,"th"),r()(),i(63,"tbody"),_(64,Y,36,28,"tr",23)(65,U,3,0,"tr",24),r()()()),t&2&&(l(5),y("Conforme al TUO del D. Leg. N\xB0 728 \xB7 ",o.contracts().length," contratos en el sistema"),l(14),u("active",o.filter()==="Todos"),l(3),s(o.counts().all),l(),u("active",o.filter()==="Vigentes"),l(3),s(o.counts().active),l(),u("active",o.filter()==="Por vencer"),l(3),s(o.counts().warning),l(),u("active",o.filter()==="Vencidos"),l(3),s(o.counts().expired),l(30),f("ngForOf",o.filteredContracts()),l(),f("ngIf",o.filteredContracts().length===0))},dependencies:[F,V,L,$,M,H,A],encapsulation:2})};export{z as ContractListComponent};
