import"./chunk-C6Q5SG76.js";var t=[{path:"",loadComponent:()=>import("./chunk-LPY32GMU.js").then(o=>o.OperationsDashboardComponent)}];export{t as OPERATIONS_ROUTES};
